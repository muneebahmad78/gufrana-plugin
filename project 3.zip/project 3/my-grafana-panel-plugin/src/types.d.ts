export interface SimpleOptions {
}
//# sourceMappingURL=types.d.ts.map