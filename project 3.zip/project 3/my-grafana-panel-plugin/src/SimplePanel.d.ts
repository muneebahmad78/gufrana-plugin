import React from 'react';
import { PanelProps } from '@grafana/data';
import { SimpleOptions } from './types';
interface Props extends PanelProps<SimpleOptions> {
}
export declare const SimplePanel: React.FC<Props>;
export {};
//# sourceMappingURL=SimplePanel.d.ts.map