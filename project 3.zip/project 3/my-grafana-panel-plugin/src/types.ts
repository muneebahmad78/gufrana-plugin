export interface SimpleOptions {}
