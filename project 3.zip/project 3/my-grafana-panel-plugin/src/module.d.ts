import { PanelPlugin } from '@grafana/data';
import { SimpleOptions } from './types';
export declare const plugin: PanelPlugin<SimpleOptions, any>;
//# sourceMappingURL=module.d.ts.map