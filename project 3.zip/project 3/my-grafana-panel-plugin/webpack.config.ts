import { Configuration } from 'webpack';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default (env: { production?: boolean }): Configuration => {
  const isProduction = env.production === true;

  return {
    mode: isProduction ? 'production' : 'development',
    entry: './src/module.ts',
    output: {
      filename: 'module.js',
      path: path.resolve(__dirname, 'dist'),
      library: {
        type: 'amd',
      },
    },
    devtool: isProduction ? false : 'eval',
    resolve: {
      extensions: ['.ts', '.tsx', '.js', '.jsx'],
    },
    module: {
      rules: [
        {
          test: /\.tsx?$/,
          use: 'ts-loader',
          exclude: /node_modules/,
        },
      ],
    },
    externals: [
      'react',
      'react-dom',
      '@grafana/ui',
      '@grafana/data',
      '@grafana/runtime',
    ],
  };
};
