# My Grafana Panel Plugin

A minimal Grafana panel plugin that displays "Developed by XYZ".

## Development

1. Install dependencies:
   ```bash
   npm install
   ```

2. Build the plugin:
   ```bash
   npm run build
   ```

3. Run Grafana with the plugin:
   ```bash
   docker run -d -p 3000:3000 -v $(pwd)/dist:/var/lib/grafana/plugins/my-grafana-panel-plugin grafana/grafana
   ```
